function ShoppingListPage() {
  return (
    <div className="container">
      <h2>Minha Lista de Compras</h2>
    </div>
  );
}

export default ShoppingListPage;