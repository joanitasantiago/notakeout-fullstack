function NotFound() {
  return (
    <div className="container">
      <h1>404 - Página não encontrada</h1>
    </div>
  );
}

export default NotFound;
