function HomePage() {
  return (
    <div className="container">
      <h1>Bem-vindo(a) ao Notakeout</h1>
      <p>Organize suas refeições com praticidade!</p>
    </div>
  );
}

export default HomePage;